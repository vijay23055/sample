import React from "react";
import { Carousel } from "react-bootstrap";

const Testimonials = () => {
  return (
    <div className="cover-testimonial">
      <Carousel className="my-5">
        <Carousel.Item>
          <div className="text-center-testimonial">
            <p>"HCLTech's solutions reduced our time to market by 30%!"</p>
            <h6>- Biopharma Company A</h6>
          </div>
        </Carousel.Item>
        <Carousel.Item>
          <div className="text-center-testimonial">
            <p>"Their digital lab management transformed our operations."</p>
            <h6>- Biopharma Company B</h6>
          </div>
        </Carousel.Item>
      </Carousel>
    </div>

  );
};

export default Testimonials;
